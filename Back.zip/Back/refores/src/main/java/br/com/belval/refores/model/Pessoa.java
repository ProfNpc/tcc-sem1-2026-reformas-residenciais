package br.com.belval.refores.model;


import java.time.LocalDateTime;
import java.util.Objects;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

/**
<<<<<<< HEAD
 * Corresponde à tabela pessoa
 */
@Entity
@Table(name = "tb_pessoa")
public class Pessoa {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;
	
	@Column(name = "nome", nullable = false, length = 150)
	private String nome;
	
	@Column(name = "cpf", nullable = false, unique = true, length = 14)
	private String cpf;

	@Column(name = "cep", nullable = false, unique = true, length = 14)
	private String cep;
	
	@Column(name = "telefone", length = 20)
	private String telefone;
	
	@Column(name = "endereco", length = 255)
	private String endereco;
	
	@Column(name = "email", length = 100)
	private String email;
	
	
	
	@Column(name = "deletado", length = 20)
	private String deletado;
	
	@Column(name = "data_criacao")
	private LocalDateTime dataCriacao;
	
	
	public Pessoa() {
		super();
	}
	
	
	public Integer getId() {
		return this.id;
	}
	
	//Método que define/altera o valor do atributo id
	public void setId(Integer id) {
		this.id = id;
	}

	//Para criar os getters e os setters podemos utilizar o atalho da IDE
	//Alt + SHIFT + S >> "Generate getters and setters"
	

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}
	
	

	public String getCpf() {
		return cpf;
	}
	
	//Método que define/altera o valor do atributo id
	public void setCpf(String cpf) {
		this.cpf = cpf;
	}

	public String getCep() {
		return cep;
	}
	
	//Método que define/altera o valor do atributo id
	public void setCep(String cep) {
		this.cep = cep;
	}



	public String getTelefone() {
		return telefone;
	}
	public void setTelefone(String telefone) {
		this.telefone = telefone;
	}

	public String getEndereco() {
		return endereco;
	}

	public void setEndereco(String endereco) {
		this.endereco = endereco;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}
	
	
		
	public LocalDateTime getDataCriacao() {
		return dataCriacao;
	}


	public void setDataCriacao(LocalDateTime dataCriacao) {
		this.dataCriacao = dataCriacao;
	}
	
	public String getDeletado() {
		return deletado;
	}

	public void setDeletado(String deletado) {
		this.deletado = deletado;
	}

	@Override
	public int hashCode() {
		return Objects.hash(id);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Pessoa other = (Pessoa) obj;
		return Objects.equals(id, other.id);
	}


	@Override
	public String toString() {
		return "Pessoa [id=" + id + ", nome=" + nome + ", cpf=" + cpf + ",cep=" + cep + ", telefone=" + telefone + ", endereco="
				+ endereco + ", email=" + email  +  ", dataCriacao=" + dataCriacao + ",deletado =" + deletado + "]";
	}



}
